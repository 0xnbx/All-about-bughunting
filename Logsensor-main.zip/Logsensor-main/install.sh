#!/bin/bash

sudo ln -s $(pwd)/logsensor.py /usr/local/bin/logsensor
logsensor