@file:Suppress("unused")

package burp

import com.dexter0us.scavenger.Extension

class BurpExtender : Extension()