# XSS.png
A XSS mind map ;)
